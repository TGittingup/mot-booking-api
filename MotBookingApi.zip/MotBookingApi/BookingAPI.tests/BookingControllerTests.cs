﻿using Xunit;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using MotBookingApi.Controllers;
using MotBookingApi.models;

namespace BookingApi.Tests
{
    public class BookingsControllerTests
    {
        [Fact]
        public void Get_ReturnsEmptyListInitially()
        {
            // Arrange
            var controller = new BookingsController();

            // Act
            var result = controller.Get();

            // Assert
            var okResult = Assert.IsType<ActionResult<IEnumerable<Booking>>>(result);
            Assert.Empty(okResult.Value);
        }

        [Fact]
        public void Post_AddsNewBooking()
        {
            // Arrange
            var controller = new BookingsController();
            var newBooking = new Booking { Id = 1, name = "Ali", carReg = "XY12 ABC", garage = "Leeds MOT", date = DateTime.Today };

            // Act
            var result = controller.Post(newBooking);

            // Assert
            var createdResult = Assert.IsType<CreatedAtActionResult>(result.Result);
            var returnValue = Assert.IsType<Booking>(createdResult.Value);
            Assert.Equal("Ali", returnValue.name);
        }

        [Fact]
        public void Delete_RemovesBooking_WhenExists()
        {
            // Arrange
            var controller = new BookingsController();
            var booking = new Booking { Id = 2, name = "Sara", carReg = "ZZ99 ZZ", garage = "Manchester MOT", date = DateTime.Today };
            controller.Post(booking);

            // Act
            var result = controller.Delete(2);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var deleted = Assert.IsType<Booking>(okResult.Value);
            Assert.Equal(2, deleted.Id);
        }

        [Fact]
        public void Delete_ReturnsNotFound_WhenBookingMissing()
        {
            // Arrange
            var controller = new BookingsController();

            // Act
            var result = controller.Delete(99);

            // Assert
            Assert.IsType<NotFoundResult>(result.Result);
        }
    }
}
