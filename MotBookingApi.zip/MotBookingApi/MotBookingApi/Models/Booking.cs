﻿using System;

namespace MotBookingApi.models;

public class Booking
{
    public int Id { get; set; }
    public string name { get; set; }
    public string carReg { get; set; }
    public DateTime date { get; set; }
    public string garage { get; set; }
}