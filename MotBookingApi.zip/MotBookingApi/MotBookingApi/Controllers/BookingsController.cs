﻿using Microsoft.AspNetCore.Mvc;
using MotBookingApi.models;

namespace MotBookingApi.Controllers
{
    [ApiController]
    [Route("bookings")]
    public class BookingsController : ControllerBase
    {
        private static List<Booking> bookings = new();

        [HttpGet]
        public ActionResult<IEnumerable<Booking>> Get()
        {
            return Ok(bookings);
        }

        [HttpPost]
        public ActionResult<Booking> Post([FromBody] Booking newBooking)
        {
            newBooking.Id = bookings.Count + 1;
            bookings.Add(newBooking);
            return CreatedAtAction(nameof(Get), new { id = newBooking.Id }, newBooking);
        }

        [HttpDelete]

        [HttpDelete("{id}")]
        public ActionResult<Booking> Delete(int id)
        {
            var booking = bookings.FirstOrDefault(b => b.Id == id);
            if (booking == null)
            {
                return NotFound(); 
            }

            bookings.Remove(booking);
            return Ok(booking); 
        }

    }
}
